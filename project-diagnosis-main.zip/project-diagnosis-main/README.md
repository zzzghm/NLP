# Medical Specialty Prediction Project
# Author: Joy Zhuge, Gemeng Zhang
This repository contains code for the our final project in CMPS 4730/6730: Natural Language Processing at Tulane University.


### Contents

- [report](report): formal report for the project
- [notebooks](notebooks): Jupyter notebooks for project development and experimentation,including the clinic_diag_final.ipynb (baseline + summarization) and clinic_diag_final_rnn_part.ipynb (rnn classifiers)
- [spark_demo](spark_demo): "python app.py" to run the demo. （need to modify the path to the data files）
