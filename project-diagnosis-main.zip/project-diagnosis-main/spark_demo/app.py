from flask import Flask,render_template,url_for,request
import pandas as pd
import pickle
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import joblib
from gensim.models import KeyedVectors
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
from torch.nn.utils.rnn import pad_sequence
#from tqdm import tqdm

app = Flask(__name__)

@app.route('/')
def home():
	return render_template('home.html')

@app.route('/predict',methods=['POST'])

def predict():
	#df= pd.read_csv("spam.csv", encoding="latin-1")
	#df.drop(['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4'], axis=1, inplace=True)
	# Features and Labels
	#df['label'] = df['class'].map({'ham': 0, 'spam': 1})
	#X = df['message']
	#y = df['label']

	# Extract Feature With CountVectorizer
	# cv = CountVectorizer()
	# X = cv.fit_transform(X) # Fit the Data
	# from sklearn.model_selection import train_test_split
	# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)
	#Naive Bayes Classifier
	# from sklearn.naive_bayes import MultinomialNB

	#clf = MultinomialNB()
	#clf.fit(X_train,y_train)
	#clf.score(X_test,y_test)
	#Alternative Usage of Saved Model
	# joblib.dump(clf, 'C:\Users\zgeme\OneDrive - Tulane University\NLP course\gzhang1-master\project\rnn_surgery_or_medicine.pkl')
	path = 'C:/Users/zgeme/OneDrive - Tulane University/NLP course/gzhang1-master/project/'
	w2v = KeyedVectors.load_word2vec_format(path+'BioWordVec_PubMed_MIMICIII_d200.vec.bin', binary=True)
	MEAN_VEC = torch.load(path+'BioMeanVec.pt')
	rnn_model = open(path+'rnn_surgery_or_medicine.pkl','rb')
	rnn = joblib.load(rnn_model)

	if request.method == 'POST':
		message = request.form['message']
		data = [message]
		rnn_input = torch.tensor([w2v[w.lower()] if w.lower() in w2v else MEAN_VEC for w in data])
		x2 = rnn_input.unsqueeze(0)
		rnn_predict = rnn.forward(x2)
		topn, top1= rnn_predict.topk(1)
		my_prediction = int(top1)
		my_prob = float(topn)
	return render_template('result.html',prediction = my_prediction, confidence = my_prob)



if __name__ == '__main__':
	class GRU_classifier(nn.Module):
    		def __init__(self, input_size, hidden_size, output_size, category_list):
        		super(GRU_classifier, self).__init__()
        
        		self.input_size = input_size
        		self.hidden_size = hidden_size
        # self.n_layer = layers
        		self.states = category_list
        #self.embedding = nn.Embedding(self.input_size, self.embedding_size)
        		self.rnn = nn.GRU(input_size = input_size, hidden_size = hidden_size)
        		self.fc = nn.Linear(hidden_size, output_size)
        		self.tanh = nn.Tanh()
        		self.softmax = nn.Softmax(dim = 1)
        # self.dropout = nn.Dropout()
        
    
    		def forward(self, inputs):
        # inilization the h0
        		h0 = torch.zeros(1, inputs.size(1), self.hidden_size)
        # forward propogation
        		hidden, _ = self.rnn(inputs, h0)
        		x = self.tanh(hidden)
        # reduce the dimension
        # x = inputs
        		x_avg = x.sum(dim = 1) / x.shape[1]
        		x_avg = x_avg.squeeze(1)
        # out = self.dropout(x_avg)
        # out = self.hidden2label(out)
        # out = self.softmax(out)
        # exstract the final forward hidden state
        ### use only the last hidden state
        # final_hidden = hidden[:,-1,:]
                
        #hidden = [batch size, hid dim * num directions]
        		dense_outputs = self.fc(x_avg)

        #Final activation function
        		outputs = self.softmax(dense_outputs)
        
        		return outputs
	
	app.run(debug=True)
