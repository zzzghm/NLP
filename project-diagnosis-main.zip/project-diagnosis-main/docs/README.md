You can create a simple slide show here by adding files to the _posts directory.

The website for this repository is viewable at: https://tulane-cmps6730.github.io/sample-project . You will have a different url for your team's repository -- e.g., if your team's repository is `project-alpha`, it will be at https://tulane-cmps6730.github.io/project-alpha.

Here is a tutorial on the Markdown syntax: https://guides.github.com/features/mastering-markdown/

I added the reveal.js submodule by `git submodule add https://github.com/hakimel/reveal.js reveal.js`
